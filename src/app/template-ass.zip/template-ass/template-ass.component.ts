import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-template-ass',
  templateUrl: './template-ass.component.html',
  styleUrls: ['./template-ass.component.css']
})
export class TemplateAssComponent implements OnInit {


    ages : number[] = [ 17,18,19,20];
    cities :string[] = ['Mumbai', 'Kolkatata','Delhi','Pune','Mumbai'];
    formData: any;
    isSubmitted: boolean;


    genders = [ 
      {
        id: '1', value: 'Male'
      },
      {
        id: '2', value: 'Female'
      }
    ]
     

  constructor() { }

  ngOnInit() {
  }
  registration(form: NgForm) {
    this.isSubmitted = true;
console.log(form);

}
}
